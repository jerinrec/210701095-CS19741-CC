# Change Log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]
### Added
- Upcoming changes:

### Changed

## 2021-12-08
### Added
- Tested compatibility for JDK17
- Supported Apple Silicon M1, tested with Zulu OpenJDK 17.0.1+12

### Changed
- Lots of code clean up and performance improvements